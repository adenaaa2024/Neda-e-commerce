# Scanner / Expected / Return / Claims — authoritative architecture

**Status:** CORRECTED — supersedes bad return_items backfill assumption  
**Branch:** `feature/phase1-latest-stash-land` @ `c78fbb8`  
**Last updated:** 2026-05-31 (`architecture-correction-history-memory-update` `20260531T120000Z`)

**Evidence:** `.cursor/audit-reports/full-scanner-expected-returns-claims-architecture-readonly/20260531T084101Z/`

Related: [EXPECTED_ALLOCATION_MODEL.md](EXPECTED_ALLOCATION_MODEL.md) · [SCANNER_OPERATOR_CONTRACTS.md](SCANNER_OPERATOR_CONTRACTS.md) · [CLAIM_ARCHITECTURE.md](CLAIM_ARCHITECTURE.md) · [DATABASE_CONTRACT.md](DATABASE_CONTRACT.md)

---

## CORRECTED rules (mandatory)

| Rule | Detail |
|------|--------|
| **`return_items`** | **Physical scanned units only** — 1 row = 1 unit; `COUNT(return_items WHERE deleted_at IS NULL)` |
| **Forecast / API / removal** | Belongs in **`expected_packages`** (+ `raw_report_uploads`, `amazon_removals`, `amazon_removal_shipments`) — **never** bulk-inserted into `return_items` |
| **Allocation** | `expected_packages` children (`build_source = 'receive_allocated'`) + `return_items.expected_item_id` set **after** physical scan via allocation RPC |
| **EP → RI linkage copy** | **Forbidden** unless RI is a **proven physical scan** (package/pallet/slip/operator receive path) |
| **Product linkage (expected)** | On **`expected_packages.resolved_product_id`** via **`product_identifier_map`** — not by bulk-filling `return_items` |
| **Product linkage (scan)** | On **`return_items.resolved_product_id`** via resolver on insert — not copied from EP in normal flow |
| **Claims (scanner)** | **`claim_lines`** (`line_grain = 'return_item'`) only after scanner issue + evidence + cutoff/module gates |
| **`package_items`** | **Forbidden** |
| **Title/OCR auto-link** | **Forbidden** |

---

## Two-grain model

| Layer | Table | Grain |
|-------|-------|-------|
| Physical scan | `return_items` | 1 row = 1 scanned unit |
| Slip OCR | `slip_contents` | 1 row = 1 slip line on a package |
| Expected forecast | `expected_packages` (root) | Group — `expected_scan_quantity` |
| Allocation unit | `expected_packages` (`receive_allocated`) | 1 child = 1 allocated unit |
| Read model | `v_inventory_item_status`, `v_inventory_status`, `v_scanned_items_counted` | Display only — not write path |

**Link direction:**

```
expected_packages → products (resolver)
return_items → expected_packages (after scan + allocate RPC)
claim_lines → return_items (after issue/evidence/cutoff)
```

---

## Valid receive path (code)

1. `operatorReceiveItem` / `insertReturn` — **quantity = 1** enforced  
2. Row anchors to `package_id` (and `pallet_id` via package)  
3. `allocate_expected_items_for_return_item_ids` RPC → `expected_item_id`  
4. Resolver sets `return_items.resolved_product_id` on insert  

**Delete/void:** `release_expected_item_unit` before soft-delete (`softVoidReturnItemWithExpectedRelease`, `voidOperatorIntakeBoxPackageAction`).

---

## Staging state (post Wave2 rollback PASS)

| Metric | Value |
|--------|------:|
| Active `return_items` | **5,366** |
| `resolved_product_id` set | **57** (restored after Wave2 rollback) |
| Bulk/orphan RIs (expected_item_id, no package) | **~5,333** — provenance/remediation **pending** |
| Proven physical scans (`package_id` set) | **~3** |

Wave2 rollback reverted unsafe `resolved_product_id` denormalization only — **no row deletes**. `products`, `expected_packages`, `product_identifier_map` **unchanged**.

---

## Claims / queue safety

| Item | Status |
|------|--------|
| Returns claims work queue | **UNSAFE** until **physical-anchor gate** (`package_id IS NOT NULL`) patched |
| `CLAIM_SCANNER_AUTO_PROMOTE_ENABLED` | **off** |
| Merge / deploy / original apply | **NO** until corrections + orphan remediation complete |

---

## Future gate (before any DB touch)

Any DB write, backfill, or migration touching scanner / expected / return / claims requires:

1. Read-only architecture evidence under `.cursor/audit-reports/`
2. Explicit operator approval under `.cursor/operator-approvals/`

---

## Next prompts (ordered)

1. **BULK-RETURN-ITEMS-PROVENANCE-READONLY**
2. **BULK-RETURN-ITEMS-QUARANTINE-APPROVAL-AND-EXECUTE**
3. **CLAIM-RETURNS-WORK-QUEUE-PHYSICAL-ANCHOR-GATE**
