# Scanner state — Neda / operator-mobile

**Branch:** `feature/phase1-latest-stash-land` @ `c78fbb8`  
**Staging:** `eiqfaapyumhixxoeltgu`  
**Last updated:** 2026-05-31 (`architecture-correction-history-memory-update` `20260531T120000Z`)

Contract reference: [SCANNER_OPERATOR_CONTRACTS.md](SCANNER_OPERATOR_CONTRACTS.md) · [SCANNER_RETURNS_CLAIMS_ARCHITECTURE.md](SCANNER_RETURNS_CLAIMS_ARCHITECTURE.md)

## CORRECTED — return_items rule

**`return_items` = physical scanned units only.** Forecast belongs in **`expected_packages`**.

| Staging metric | Value |
|----------------|------:|
| Active `return_items` | **5,366** |
| Proven physical scans (`package_id` set) | **~3** |
| Bulk/orphan (expected link, no package) | **~5,333** |
| `resolved_product_id` after Wave2 rollback | **57** |

Wave2 EP→RI `resolved_product_id` copy **reverted (PASS)**. Orphan row remediation **pending**.

## Item-level receive (canonical path)

1 RI per scan → `operatorReceiveItem` / `insertReturn` (qty=1) → `allocate_expected_items_for_return_item_ids` → `expected_item_id`.

## Neda delete / move / void (implemented)

| Action | Path |
|--------|------|
| Delete item | `operatorDeleteReturnItem` → `release_expected_item_unit` → soft void |
| Void box | `voidOperatorIntakeBoxPackageAction` → release all RIs → soft void package |
| Move box | `moveOperatorIntakeBoxToPalletAction` → reparent package → `move_expected_item_unit` per RI |

## Product spine true linkage — staging PASS

Execute: `product-spine-view-linkage-staging-execute/20260530T171500Z/` — linkage on **expected_packages** spine, not bulk RI fill.

## DB parity — slip/view linkage

Staging **PASS** `20260529T231120Z` · Original **PASS** `20260529T234437Z`

## Deploy gate

Merge **WAIT** — no merge/deploy/original apply until orphan RI remediation + claims physical-anchor gate complete.

## Evidence

`full-scanner-expected-returns-claims-architecture-readonly/20260531T084101Z/` · `product-spine-view-linkage-staging-execute/20260530T171500Z/`
