# Current state — canonical system memory

**Last updated:** 2026-05-31 (`architecture-correction-history-memory-update` `20260531T120000Z`)  
**Branch:** `feature/phase1-latest-stash-land` @ `c78fbb8` · **main** `4402064` — **no merge**

## CORRECTED — Scanner / Expected / Return / Claims

**Full doc:** [SCANNER_RETURNS_CLAIMS_ARCHITECTURE.md](SCANNER_RETURNS_CLAIMS_ARCHITECTURE.md)

| Rule | Status |
|------|--------|
| `return_items` = physical scanned units only | **LOCKED** |
| Forecast/API/removal in `expected_packages` — not bulk `return_items` | **LOCKED** |
| No EP→RI `resolved_product_id` bulk copy without proven physical scan | **LOCKED** |
| Wave2 linkage rollback | **PASS** — RI resolved count **57**; active RI **5,366**; spine tables unchanged |
| Bulk/orphan RIs on staging | **~5,333** — provenance/remediation **pending** |
| Returns claims work queue | **UNSAFE** until physical-anchor gate patched |
| Auto-promote | **off** |
| Merge / deploy / original apply | **NO** until corrections complete |

**Future gate:** read-only architecture audit + operator approval before any scanner/expected/return/claims DB write.

Evidence: `.cursor/audit-reports/full-scanner-expected-returns-claims-architecture-readonly/20260531T084101Z/`

---

## Product Core — protected backbone

**Full doc:** [PRODUCT_CORE_ARCHITECTURE.md](PRODUCT_CORE_ARCHITECTURE.md)

| Dimension | Completion |
|-----------|------------|
| Architecture | **90-95%** |
| Operational / data | **65-75%** |

Core changes require: read-only audit → parity proof → risk report → operator approval.

## Execution policy (mandatory)

```
census -> classify -> sample dry-run -> approval -> sample apply -> verify -> next wave
```

| Gate | Rule |
|------|------|
| Broad product import | **FORBIDDEN** |
| Product Core rewrite | **FORBIDDEN** without change gate |
| Merge to main | **NO** |
| Cron apply | **off** |
| Original DB changes | **explicit approval only** |
| Scanner/return/claims DB writes | **architecture audit + approval required** |

## Product sheet import dry-run (read-only)

| Bucket | Count |
|--------|------:|
| Total rows | **4479** |
| Needs-review / conflicts | **3399** |

**Next path:** Phase F conflict resolution → max-**25** sample wave (after P0 scanner remediation).

## Product enrichment

Browser-loop update button — needs backend job in **waves**.

## Claims (returns-first)

Cutoff dates **unconfigured** · returns work queue **unsafe until physical-anchor gate** · auto-promote **off** · manual grouping UI **not built**.

## Removal

Non-overflow mismatch **0** · duplicate EP **0** · cron **off**

Detail: [NEXT_ACTIONS.md](NEXT_ACTIONS.md) · [ROADMAP.md](ROADMAP.md) · [SCANNER_RETURNS_CLAIMS_ARCHITECTURE.md](SCANNER_RETURNS_CLAIMS_ARCHITECTURE.md)

**Last memory sync:** `architecture-correction-history-memory-update/20260531T120000Z/`
