# Next actions — canonical

**Branch:** `feature/phase1-latest-stash-land` @ `c78fbb8` · **main** `4402064` (not merged)  
**Last updated:** 2026-05-31 (`architecture-correction-history-memory-update` `20260531T120000Z`)

**Architecture:** [SCANNER_RETURNS_CLAIMS_ARCHITECTURE.md](SCANNER_RETURNS_CLAIMS_ARCHITECTURE.md) — corrected; Wave2 rollback **PASS**; ~5,333 orphan RIs pending remediation.

**Product Core:** protected backbone — see [PRODUCT_CORE_ARCHITECTURE.md](PRODUCT_CORE_ARCHITECTURE.md).

---

## Execution policy (all waves)

`census -> classify -> sample dry-run -> approval -> sample apply -> verify -> next wave`

**Scanner/expected/return/claims DB writes:** read-only architecture audit + `.cursor/operator-approvals/` file **required first**.

---

## P0 — Scanner / return architecture remediation

1. **BULK-RETURN-ITEMS-PROVENANCE-READONLY** — trace ~5,333 bulk/orphan `return_items` (2026-05-30 load); ID list; no deletes  
2. **BULK-RETURN-ITEMS-QUARANTINE-APPROVAL-AND-EXECUTE** — soft-delete orphans + `release_expected_item_unit` per row (separate approval)  
3. **CLAIM-RETURNS-WORK-QUEUE-PHYSICAL-ANCHOR-GATE** — require `package_id IS NOT NULL` in queue + promote paths  

**SUPERSEDES (do not execute):** EXPECTED-LINKAGE-CLASS-A-STAGING-SAMPLE · RETURN-ITEMS-DRIFT-REVIEW · EP→RI linkage backfill waves

---

## P0 — Product sheet (after scanner P0)

4. **PRODUCT-SHEET-IMPORT-PHASE-F-CONFLICT-RESOLUTION** — **3399** needs-review/conflicts  
5. **PRODUCT-SHEET-IMPORT-MAX-25-SAMPLE-WAVE** — max **25** rows after Phase F  

**Forbidden:** broad product import

---

## P1 — Product enrichment + claims config

6. **PRODUCT-ENRICHMENT-BACKEND-JOB-WAVES** — replace browser-loop update button  
7. **CLAIMS-RETURNS-FIRST-CONFIGURE** — cutoff dates; module scope + manual grouping UI (after physical-anchor gate)  

---

## P2 — Gated (unchanged)

8. **CRON-APPLY-ENABLE** — **off**  
9. **REMOVAL-NOV-DEC-SPLIT-WINDOW-FETCH-RESUME**  
10. **SUPERADMIN-AUTOMATION-SETTINGS** — planned only  

---

## Done

- [x] Full scanner/expected/returns/claims architecture recovery (read-only) — `20260531T084101Z`  
- [x] Wave2 `resolved_product_id` rollback — **PASS** (active RI **5,366**; resolved **57**; spine unchanged)  
- [x] Product sheet import dry-run (read-only)  
- [x] Expected linkage census (read-only) — **superseded** by architecture correction  
- [x] Removal rebuild mismatch **0** · duplicate EP **0**

---

## Hard policy

| Rule | Value |
|------|-------|
| Merge to main | **NO** |
| Deploy / original apply | **NO** until scanner remediation complete |
| Cron apply | **disabled** |
| Original DB writes | **explicit approval only** |
| Broad product import | **FORBIDDEN** |
| Bulk `return_items` from expected/API | **FORBIDDEN** |
| EP→RI linkage copy without physical scan | **FORBIDDEN** |
| Claims auto-promote | **off** |
